﻿using AzureSQLDBQnABot.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace AzureSQLDBQnABot.Dialogs
{
    public class QnAMakerDialog : CancelAndHelpDialog
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;

        public QnAMakerDialog(IConfiguration configuration, IHttpClientFactory httpClientFactory)
            : base(nameof(QnAMakerDialog))
        {
            _configuration = configuration;
            _httpClientFactory = httpClientFactory;

            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                IntroStepAsync,
                ActStepAsync,
                FinalStepAsync,
            }));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> IntroStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter employee code to get vaccination details.")
            }, cancellationToken);
        }

        private async Task<DialogTurnResult> ActStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            string emp = (string)stepContext.Result;
            APIDialog2 api = new APIDialog2();
            api.emp = emp;
            HartaVax vax = await api.APIStartAsync();


            string vacDetails = "Employee Name: " + vax.Name + "\n\n";

            if (!string.IsNullOrEmpty(vax.Name))
            {
                foreach (Vaccination v in vax.vac)
                {
                    vacDetails += "Vaccination Date: " + v.InjectionDateString + " (" + v.Vaccine + ")" + "\n\n";
                    // = MessageFactory.Text(vacDetails);
                    //Prompt = MessageFactory.Text(vacDetails)

                }
                await stepContext.Context.SendActivityAsync(MessageFactory.Text(vacDetails), cancellationToken);
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Vaccination details not found for this employee id."), cancellationToken);
            }

            //PASTING BELOW HERE!!!

            //PASTING ABOVE HERE!!!
            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions
            {

                
                Prompt = MessageFactory.Text("Would you like to search for more Hartanians?")

            }, cancellationToken);
        }

        private async Task<DialogTurnResult> FinalStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if ((bool)stepContext.Result)
            {
                return await stepContext.ReplaceDialogAsync(InitialDialogId, null, cancellationToken);
            }
            else
            {
                return await stepContext.EndDialogAsync(null, cancellationToken);
            }
        }
    }
}