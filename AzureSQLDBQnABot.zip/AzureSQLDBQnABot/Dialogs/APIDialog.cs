﻿using AzureSQLDBQnABot.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net;
using Newtonsoft.Json;

namespace AzureSQLDBQnABot.Dialogs
{


    public class APIDialog2
    {
        public string emp = "";
        //TESTING CODE FROM API DIALOG CLASS (SQLDB QUERY)   
        private async Task<DialogTurnResult> IntroStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions
            {
                Prompt = MessageFactory.Text("Please enter the Employee Code for API Query:")
            }, cancellationToken);
        }

        public HttpClient client = new HttpClient();

        public async Task<HartaVax> GetProductAsync(string emp)
        {
            HartaVax product = null;
            HttpResponseMessage response = await client.GetAsync("https://sharepointnintex.hartalega.com.my/custom/VacAPI/api/Vac/" + emp);
            if (response.IsSuccessStatusCode)
            {
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();

                product = JsonConvert.DeserializeObject<HartaVax>(responseBody);
            }
            return product;
        }

        public async Task<HartaVax> APIStartAsync()
        {
            return await RunAsync( emp);
        }

        public async Task<HartaVax> RunAsync(string emp)
        {
            // Update port # in the following line.
            client.BaseAddress = new Uri("https://sharepointnintexdev.hartalega.com.my/custom/VacAPI/api/Vac/" + emp);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            HartaVax product = new HartaVax();
            try
            {
                product =  await GetProductAsync(emp);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return product;
        }
    }
}