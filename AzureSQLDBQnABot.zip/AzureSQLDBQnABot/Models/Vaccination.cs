﻿namespace AzureSQLDBQnABot.Models
{
    public class Vaccination
    {
        public string  InjectionDateString { get; set; }
        public string Vaccine { get; set; }
    }
}
