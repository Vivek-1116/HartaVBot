﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace AzureSQLDBQnABot.Models
{
    public partial class Employee
    {
        public string Empid { get; set; }
        public string Empname { get; set; }

        public string Empdes { get; set; }

        public string Empext { get; set; }
    }
}
