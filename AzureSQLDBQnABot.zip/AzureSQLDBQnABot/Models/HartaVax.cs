﻿using System.Collections.Generic;

namespace AzureSQLDBQnABot.Models
{

    public class HartaVax
    {
        public string Name { get; set; }

        public List <Vaccination>  vac { get; set; }


        }
}
