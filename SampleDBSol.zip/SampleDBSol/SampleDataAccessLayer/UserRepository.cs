﻿using SampleDataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace SampleDataAccessLayer
{
    public class UserRepository
    {
        SampleDB2Context context;
        public SampleDB2Context Context { get { return context; } }
        public UserRepository()
        {
            context = new SampleDB2Context();
        }

        public Employee FetchEmployeeDetails(string empid)
        {
            Employee employee;
            try
            {
                employee = (from r in Context.Employee
                            where r.EmpId == empid
                            select r).FirstOrDefault();
            }
            catch (Exception)
            {
                throw;
            }
            return employee;
        }
    }
}