﻿using SampleDataAccessLayer;
using SampleDataAccessLayer.Models;
using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            UserRepository userRepository = new UserRepository();
            Employee employee = userRepository.FetchEmployeeDetails("E1001");
            Console.WriteLine(employee.EmpId + " - " + employee.EmpName);
        }
    }
}